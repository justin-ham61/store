const sessionKey = 'casadecleaners1'

module.export = {
    sessionKey
}